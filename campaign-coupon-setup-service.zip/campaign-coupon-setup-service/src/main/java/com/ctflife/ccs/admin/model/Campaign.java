package com.ctflife.ccs.admin.model;

import java.util.Objects;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.ArrayList;
import java.util.List;
//import org.threeten.bp.LocalDate;
//import org.threeten.bp.OffsetDateTime;
 
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.validation.annotation.Validated;
import org.springframework.data.annotation.Id;


import io.swagger.v3.oas.annotations.media.Schema;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;


/**
 * Campaign
 */
@Validated
@Document (collection = "Campaign")
public class Campaign   {
	
	@Id
	private int id;
	  	  	
  @JsonProperty("campaignCode")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String campaignCode = null;

  @JsonProperty("campaignName")
  @Valid
  private List<CampaignName> campaignName = null;
  @JsonProperty("campaignDesc")
  @Valid
  private List<CampaignDesc> campaignDesc = null;
  /**
   * Gets or Sets campaignType
   */
  public enum CampaignTypeEnum {
    DISCOUNTCAMPAIGN("DiscountCampaign"),
    
    REFUNDCAMPAIGN("RefundCampaign"),
    
    COUPONCAMPAIGN("CouponCampaign");

    private String value;

    CampaignTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static CampaignTypeEnum fromValue(String text) {
      for (CampaignTypeEnum b : CampaignTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("campaignType")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private CampaignTypeEnum campaignType = null;

  @JsonProperty("campaignStartDate")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Date campaignStartDate = null;

  @JsonProperty("campaignEndDate")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Date campaignEndDate = null;

  @JsonProperty("channels")
  @Valid
  private List<Channel> channels = null;
  @JsonProperty("planCode")
  @Valid
  private List<String> planCode = null;
  @JsonProperty("flyers")
  @Valid
  private List<Flyer> flyers = null;
  @JsonProperty("coExistFlag")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Boolean coExistFlag = null;

  /**
   * Campaign Activation Status
   */
  public enum StatusEnum {
    ACTIVE("active"),
    
    INACTIVE("inactive");

    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static StatusEnum fromValue(String text) {
      for (StatusEnum b : StatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("status")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private StatusEnum status = null;

  @JsonProperty("approvalDate")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Date approvalDate = null;

  @JsonProperty("campaignDiscountRulesLocation")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String campaignDiscountRulesLocation = null;

  @JsonProperty("version")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Integer version = null;

  @JsonProperty("tag")
  @Valid
  private List<String> tag = null;
  
  private List<DiscountRuleSet> discountRulesets = null;

  public Campaign campaignCode(String campaignCode) { 

    this.campaignCode = campaignCode;
    return this;
  }

  /**
   * Get campaignCode
   * @return campaignCode
   **/
  
  @Schema(example = "Q2HC16825", description = "")
  
  public String getCampaignCode() {  
    return campaignCode;
  }



  public void setCampaignCode(String campaignCode) { 
    this.campaignCode = campaignCode;
  }

  public Campaign campaignName(List<CampaignName> campaignName) { 

    this.campaignName = campaignName;
    return this;
  }

  public Campaign addCampaignNameItem(CampaignName campaignNameItem) {
    if (this.campaignName == null) {
      this.campaignName = new ArrayList<CampaignName>();
    }
    this.campaignName.add(campaignNameItem);
    return this;
  }

  /**
   * Get campaignName
   * @return campaignName
   **/
  
  @Schema(description = "")
  @Valid
  public List<CampaignName> getCampaignName() {  
    return campaignName;
  }



  public void setCampaignName(List<CampaignName> campaignName) { 
    this.campaignName = campaignName;
  }

  public Campaign campaignDesc(List<CampaignDesc> campaignDesc) { 

    this.campaignDesc = campaignDesc;
    return this;
  }

  public Campaign addCampaignDescItem(CampaignDesc campaignDescItem) {
    if (this.campaignDesc == null) {
      this.campaignDesc = new ArrayList<CampaignDesc>();
    }
    this.campaignDesc.add(campaignDescItem);
    return this;
  }

  /**
   * Get campaignDesc
   * @return campaignDesc
   **/
  
  @Schema(description = "")
  @Valid
  public List<CampaignDesc> getCampaignDesc() {  
    return campaignDesc;
  }



  public void setCampaignDesc(List<CampaignDesc> campaignDesc) { 
    this.campaignDesc = campaignDesc;
  }

  public Campaign campaignType(CampaignTypeEnum campaignType) { 

    this.campaignType = campaignType;
    return this;
  }

  /**
   * Get campaignType
   * @return campaignType
   **/
  
  @Schema(description = "")
  
  public CampaignTypeEnum getCampaignType() {  
    return campaignType;
  }



  public void setCampaignType(CampaignTypeEnum campaignType) { 
    this.campaignType = campaignType;
  }

  public Campaign campaignStartDate(Date campaignStartDate) { 

    this.campaignStartDate = campaignStartDate;
    return this;
  }

  /**
   * Get campaignStartDate
   * @return campaignStartDate
   **/
  
  @Schema(description = "")
  
@Valid
  public Date getCampaignStartDate() {  
    return campaignStartDate;
  }



  public void setCampaignStartDate(Date campaignStartDate) { 
    this.campaignStartDate = campaignStartDate;
  }

  public Campaign campaignEndDate(Date campaignEndDate) { 

    this.campaignEndDate = campaignEndDate;
    return this;
  }

  /**
   * Get campaignEndDate
   * @return campaignEndDate
   **/
  
  @Schema(description = "")
  
@Valid
  public Date getCampaignEndDate() {  
    return campaignEndDate;
  }



  public void setCampaignEndDate(Date campaignEndDate) { 
    this.campaignEndDate = campaignEndDate;
  }

  public Campaign channels(List<Channel> channels) { 

    this.channels = channels;
    return this;
  }

  public Campaign addChannelsItem(Channel channelsItem) {
    if (this.channels == null) {
      this.channels = new ArrayList<Channel>();
    }
    this.channels.add(channelsItem);
    return this;
  }

  /**
   * Get channels
   * @return channels
   **/
  
  @Schema(description = "")
  @Valid
  public List<Channel> getChannels() {  
    return channels;
  }



  public void setChannels(List<Channel> channels) { 
    this.channels = channels;
  }

  public Campaign planCode(List<String> planCode) { 

    this.planCode = planCode;
    return this;
  }

  public Campaign addPlanCodeItem(String planCodeItem) {
    if (this.planCode == null) {
      this.planCode = new ArrayList<String>();
    }
    this.planCode.add(planCodeItem);
    return this;
  }

  /**
   * Plan Code list of the Campaign, specify \"ALLExceptILAS\" if Campaign applicable to ALL Plan except ILAS
   * @return planCode
   **/
  
  @Schema(example = "[\"CPON1\",\"MW2IU\"]", description = "Plan Code list of the Campaign, specify \"ALLExceptILAS\" if Campaign applicable to ALL Plan except ILAS")
  
  public List<String> getPlanCode() {  
    return planCode;
  }



  public void setPlanCode(List<String> planCode) { 
    this.planCode = planCode;
  }

  public Campaign flyers(List<Flyer> flyers) { 

    this.flyers = flyers;
    return this;
  }

  public Campaign addFlyersItem(Flyer flyersItem) {
    if (this.flyers == null) {
      this.flyers = new ArrayList<Flyer>();
    }
    this.flyers.add(flyersItem);
    return this;
  }

  /**
   * Get flyers
   * @return flyers
   **/
  
  @Schema(description = "")
  @Valid
  public List<Flyer> getFlyers() {  
    return flyers;
  }



  public void setFlyers(List<Flyer> flyers) { 
    this.flyers = flyers;
  }

  public Campaign coExistFlag(Boolean coExistFlag) { 

    this.coExistFlag = coExistFlag;
    return this;
  }

  /**
   * Applicable to Product campaign internally only. i.e. can be co-existed with campaigns from other dept such as K Dollar coupon
   * @return coExistFlag
   **/
  
  @Schema(description = "Applicable to Product campaign internally only. i.e. can be co-existed with campaigns from other dept such as K Dollar coupon")
  
  public Boolean isCoExistFlag() {  
    return coExistFlag;
  }



  public void setCoExistFlag(Boolean coExistFlag) { 
    this.coExistFlag = coExistFlag;
  }

  public Campaign status(StatusEnum status) { 

    this.status = status;
    return this;
  }

  /**
   * Campaign Activation Status
   * @return status
   **/
  
  @Schema(example = "active", description = "Campaign Activation Status")
  
  public StatusEnum getStatus() {  
    return status;
  }



  public void setStatus(StatusEnum status) { 
    this.status = status;
  }

  public Campaign approvalDate(Date approvalDate) { 

    this.approvalDate = approvalDate;
    return this;
  }

  /**
   * Get approvalDate
   * @return approvalDate
   **/
  
  @Schema(description = "")
  
@Valid
  public Date getApprovalDate() {  
    return approvalDate;
  }



  public void setApprovalDate(Date approvalDate) { 
    this.approvalDate = approvalDate;
  }

  public Campaign campaignDiscountRulesLocation(String campaignDiscountRulesLocation) { 

    this.campaignDiscountRulesLocation = campaignDiscountRulesLocation;
    return this;
  }

  /**
   * URL of the campaign discount rules spreadsheet per Campaign
   * @return campaignDiscountRulesLocation
   **/
  
  @Schema(example = "https://mystorage_location/campaignrules/discount_rules_CAMPAIGN1_version.xlsx", description = "URL of the campaign discount rules spreadsheet per Campaign")
  
  public String getCampaignDiscountRulesLocation() {  
    return campaignDiscountRulesLocation;
  }



  public void setCampaignDiscountRulesLocation(String campaignDiscountRulesLocation) { 
    this.campaignDiscountRulesLocation = campaignDiscountRulesLocation;
  }

  public Campaign version(Integer version) { 

    this.version = version;
    return this;
  }

  /**
   * Get version
   * @return version
   **/
  
  @Schema(description = "")
  
  public Integer getVersion() {  
    return version;
  }



  public void setVersion(Integer version) { 
    this.version = version;
  }

  public Campaign tag(List<String> tag) { 

    this.tag = tag;
    return this;
  }

  public Campaign addTagItem(String tagItem) {
    if (this.tag == null) {
      this.tag = new ArrayList<String>();
    }
    this.tag.add(tagItem);
    return this;
  }

  /**
   * Get tag
   * @return tag
   **/
  
  @Schema(example = "[\"hot\",\"new\"]", description = "")
  
  public List<String> getTag() {  
    return tag;
  }



  public void setTag(List<String> tag) { 
    this.tag = tag;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Campaign campaign = (Campaign) o;
    return Objects.equals(this.campaignCode, campaign.campaignCode) &&
        Objects.equals(this.campaignName, campaign.campaignName) &&
        Objects.equals(this.campaignDesc, campaign.campaignDesc) &&
        Objects.equals(this.campaignType, campaign.campaignType) &&
        Objects.equals(this.campaignStartDate, campaign.campaignStartDate) &&
        Objects.equals(this.campaignEndDate, campaign.campaignEndDate) &&
        Objects.equals(this.channels, campaign.channels) &&
        Objects.equals(this.planCode, campaign.planCode) &&
        Objects.equals(this.flyers, campaign.flyers) &&
        Objects.equals(this.coExistFlag, campaign.coExistFlag) &&
        Objects.equals(this.status, campaign.status) &&
        Objects.equals(this.approvalDate, campaign.approvalDate) &&
        Objects.equals(this.campaignDiscountRulesLocation, campaign.campaignDiscountRulesLocation) &&
        Objects.equals(this.version, campaign.version) &&
        Objects.equals(this.tag, campaign.tag);
  }

  @Override
  public int hashCode() {
    return Objects.hash(campaignCode, campaignName, campaignDesc, campaignType, campaignStartDate, campaignEndDate, channels, planCode, flyers, coExistFlag, status, approvalDate, campaignDiscountRulesLocation, version, tag);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Campaign {\n");
    
    sb.append("    campaignCode: ").append(toIndentedString(campaignCode)).append("\n");
    sb.append("    campaignName: ").append(toIndentedString(campaignName)).append("\n");
    sb.append("    campaignDesc: ").append(toIndentedString(campaignDesc)).append("\n");
    sb.append("    campaignType: ").append(toIndentedString(campaignType)).append("\n");
    sb.append("    campaignStartDate: ").append(toIndentedString(campaignStartDate)).append("\n");
    sb.append("    campaignEndDate: ").append(toIndentedString(campaignEndDate)).append("\n");
    sb.append("    channels: ").append(toIndentedString(channels)).append("\n");
    sb.append("    planCode: ").append(toIndentedString(planCode)).append("\n");
    sb.append("    flyers: ").append(toIndentedString(flyers)).append("\n");
    sb.append("    coExistFlag: ").append(toIndentedString(coExistFlag)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    approvalDate: ").append(toIndentedString(approvalDate)).append("\n");
    sb.append("    campaignDiscountRulesLocation: ").append(toIndentedString(campaignDiscountRulesLocation)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    tag: ").append(toIndentedString(tag)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public List<DiscountRuleSet> getDiscountRulesets() {
	return discountRulesets;
}

public void setDiscountRulesets(List<DiscountRuleSet> discountRulesets) {
	this.discountRulesets = discountRulesets;
}


}
