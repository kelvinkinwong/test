package com.ctflife.ccs.admin.model;

import java.util.Objects;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;


/**
 * CommissionSacrifice
 */

public class CommissionSacrifice   {
  @JsonProperty("producerCode")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String producerCode = null;

  @JsonProperty("startDate")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Date startDate = null;

  @JsonProperty("endDate")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Date endDate = null;

  @JsonProperty("commisionSacrificeRate")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private BigDecimal commisionSacrificeRate = null;


  public CommissionSacrifice producerCode(String producerCode) { 

    this.producerCode = producerCode;
    return this;
  }

  /**
   * Producer Code 'XXXXXXX' (7-digitals numeric) under distribution channel of the campaign  of the assigned producer with the commission sacrifice rate
   * @return producerCode
   **/
  
  @Schema(example = "0380466", description = "Producer Code 'XXXXXXX' (7-digitals numeric) under distribution channel of the campaign  of the assigned producer with the commission sacrifice rate")
  
  public String getProducerCode() {  
    return producerCode;
  }



  public void setProducerCode(String producerCode) { 
    this.producerCode = producerCode;
  }

  public CommissionSacrifice startDate(Date startDate) { 

    this.startDate = startDate;
    return this;
  }

  /**
   * Commission Sacrifice Start Date
   * @return startDate
   **/
  
  @Schema(description = "Commission Sacrifice Start Date")
  
@Valid
  public Date getStartDate() {  
    return startDate;
  }



  public void setStartDate(Date startDate) { 
    this.startDate = startDate;
  }

  public CommissionSacrifice endDate(Date endDate) { 

    this.endDate = endDate;
    return this;
  }

  /**
   * Commission Sacrifice End Date
   * @return endDate
   **/
  
  @Schema(description = "Commission Sacrifice End Date")
  
@Valid
  public Date getEndDate() {  
    return endDate;
  }



  public void setEndDate(Date endDate) { 
    this.endDate = endDate;
  }

  public CommissionSacrifice commisionSacrificeRate(BigDecimal commisionSacrificeRate) { 

    this.commisionSacrificeRate = commisionSacrificeRate;
    return this;
  }

  /**
   * Commission Sacrifice Rate
   * @return commisionSacrificeRate
   **/
  
  @Schema(example = "4.5", description = "Commission Sacrifice Rate")
  
@Valid
  public BigDecimal getCommisionSacrificeRate() {  
    return commisionSacrificeRate;
  }



  public void setCommisionSacrificeRate(BigDecimal commisionSacrificeRate) { 
    this.commisionSacrificeRate = commisionSacrificeRate;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CommissionSacrifice commissionSacrifice = (CommissionSacrifice) o;
    return Objects.equals(this.producerCode, commissionSacrifice.producerCode) &&
        Objects.equals(this.startDate, commissionSacrifice.startDate) &&
        Objects.equals(this.endDate, commissionSacrifice.endDate) &&
        Objects.equals(this.commisionSacrificeRate, commissionSacrifice.commisionSacrificeRate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(producerCode, startDate, endDate, commisionSacrificeRate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CommissionSacrifice {\n");
    
    sb.append("    producerCode: ").append(toIndentedString(producerCode)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    endDate: ").append(toIndentedString(endDate)).append("\n");
    sb.append("    commisionSacrificeRate: ").append(toIndentedString(commisionSacrificeRate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
