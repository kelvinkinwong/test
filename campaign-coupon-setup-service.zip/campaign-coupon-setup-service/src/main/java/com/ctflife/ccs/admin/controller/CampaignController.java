package com.ctflife.ccs.admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ctflife.ccs.admin.exception.ResourceNotFoundException;
import com.ctflife.ccs.admin.model.Campaign;
import com.ctflife.ccs.admin.model.DiscountRuleSet;

import com.ctflife.ccs.admin.repository.CampaignRepository;
//import com.ctflife.ccs.admin.service.SequenceGeneratorService;

/*@CrossOrigin(origins = "http://localhost:4200")*/
@RestController
@RequestMapping("/ccs-admin/v1")
public class CampaignController {
	@Autowired
	private CampaignRepository campaignRepository;
	
	//@Autowired
	//private SequenceGeneratorService sequenceGeneratorService;

	@GetMapping("/campaign")
	public List<Campaign> getAllCampaigns() {
		return campaignRepository.findAll();
	}
	
	@GetMapping("/campaign/{id}")
	public ResponseEntity<Campaign> getCampaignById(@PathVariable(value = "id") int campaignId)
			throws ResourceNotFoundException {
		Campaign campaign = campaignRepository.findById(campaignId)
				.orElseThrow(() -> new ResourceNotFoundException("Campaign not found for this id :: " + campaignId));
		return ResponseEntity.ok().body(campaign);
	}

	@PostMapping("/campaign")
	public Campaign createCampaign(@RequestBody Campaign inCampaign) {
		
		Campaign campaign = new Campaign();
		
		campaign.setId(inCampaign.getId());
		campaign.setCampaignCode(inCampaign.getCampaignCode());
		campaign.setCampaignName(inCampaign.getCampaignName());
		campaign.setCampaignDesc(inCampaign.getCampaignDesc());
		campaign.setCampaignStartDate(inCampaign.getCampaignStartDate());
		campaign.setCampaignEndDate(inCampaign.getCampaignEndDate());
		campaign.setChannels(inCampaign.getChannels());
		campaign.setPlanCode(inCampaign.getPlanCode());
		campaign.setFlyers(inCampaign.getFlyers());
		campaign.setTag(inCampaign.getTag());
		campaign.setApprovalDate(inCampaign.getApprovalDate());
		campaign.setCampaignDiscountRulesLocation(inCampaign.getCampaignDiscountRulesLocation());
		campaign.setCoExistFlag(inCampaign.isCoExistFlag());
		campaign.setStatus(inCampaign.getStatus());
		campaign.setVersion(inCampaign.getVersion());
		
		String excelFilePath = "/Users/kelvinwong/Documents/discountRulesetv01.xlsx";
		boolean logDiscountEntry = false;
		boolean campaignMatchIndicator = false;
		DiscountRuleSet discountRuleSet = null;
		List<DiscountRuleSet> discountRuleSets = new ArrayList<DiscountRuleSet>();

		 // Try block to check for exceptions 
        try { 
  
            // Reading file from local directory 
            FileInputStream file = new FileInputStream(excelFilePath); 
  
            try (// Create Workbook instance holding reference to 
			            // .xlsx file 
            	XSSFWorkbook workbook = new XSSFWorkbook(file)) {
				// Get first/desired sheet from the workbook 
				XSSFSheet sheet = workbook.getSheetAt(0); 
  
				// Iterate through each rows one by one 
				Iterator<Row> rowIterator = sheet.iterator(); 
  
				// Till there is an element condition holds true 
				while (rowIterator.hasNext()) {   
				    Row row = rowIterator.next(); 
  
				    for (Cell cell: row)
				    {
				    	if (cell.getCellType() == CellType.NUMERIC)
				    	{
				    		if (logDiscountEntry)
				    		{
				    			if (discountRuleSet != null)
				    			{
				    				if (cell.getColumnIndex() == 1)
			    					{
			    						discountRuleSet.setApeFrom((long) cell.getNumericCellValue());			    					
			    					} else if (cell.getColumnIndex() == 2)
			    					{
			    						discountRuleSet.setApeTo((long) cell.getNumericCellValue());			    								    					
			    					} else if (cell.getColumnIndex() == 4)
			    					{
			    						discountRuleSet.setNumOfFamMemEligibleFrom((int) cell.getNumericCellValue());
			    					} else if (cell.getColumnIndex() == 5)
			    					{
			    						discountRuleSet.setNumOfFamMemEligibleTo((int) cell.getNumericCellValue());
			    					} else if (cell.getColumnIndex() == 12)
			    					{
			    						discountRuleSet.setMinAP((long) cell.getNumericCellValue());
			    					} else if (cell.getColumnIndex() == 20)
			    					{
			    						discountRuleSet.setDiscountId((int) cell.getNumericCellValue());
			    					}
				    			}				    			    			
				    		}
				    	} else if (cell.getCellType() == CellType.BOOLEAN)
				    	{
				    		if (logDiscountEntry)
				    		{
			    				if (cell.getColumnIndex() == 8)
			    				{
			    					discountRuleSet.setExistingCustomer(cell.getBooleanCellValue());
			    				} else if (cell.getColumnIndex() == 3)
			    				{
			    					discountRuleSet.setApeMeasured(cell.getBooleanCellValue());
			    				} else if (cell.getColumnIndex()== 7)
			    				{
			    					discountRuleSet.setDiffInsuredInDesignatedPolicy(cell.getBooleanCellValue());
			    				}
				    		}				    		
				    	} else if (cell.getCellType() == CellType.STRING)
				    	{
				    		if (cell.getColumnIndex() == 0 && cell.getStringCellValue().length()>5 && cell.getStringCellValue().substring(0, 5).equals("Rule-"))
				    		{
				    			logDiscountEntry = true;				    			
				    			discountRuleSet = new DiscountRuleSet();
				    		}
				    		
				    		if (logDiscountEntry)
				    		{
				    			if (discountRuleSet != null)
				    			{
				    				if (cell.getColumnIndex() == 6)
				    				{
				    					List<String> designedPlanList = new ArrayList<String>();
				    			        StringTokenizer st=new StringTokenizer(cell.getStringCellValue(),",");
				    			        
				    			        while(st.hasMoreTokens()) { 
				    			        	designedPlanList.add(st.nextToken().replace("\"", ""));
				    			        }				    					
				    					
				    					discountRuleSet.setDesignatedPlanInPolicy(designedPlanList);
				    				} else if (cell.getColumnIndex() == 10)
				    				{
				    					List<String> coExistPurchasePlanList = new ArrayList<String>();
				    			        StringTokenizer st=new StringTokenizer(cell.getStringCellValue(),",");
				    			        
				    			        while(st.hasMoreTokens()) { 
				    			        	coExistPurchasePlanList.add(st.nextToken().replace("\"", ""));
				    			        }				    					
				    					
				    					discountRuleSet.setCoExistPurchasePlan(coExistPurchasePlanList);
				    				} else if (cell.getColumnIndex()== 11)
				    				{
				    					discountRuleSet.setPayTerm(cell.getStringCellValue());
				    				} else if (cell.getColumnIndex()== 13)
				    				{
				    					discountRuleSet.setxMonths(cell.getStringCellValue().replace("\"", ""));
				    				} else if (cell.getColumnIndex()== 14)
				    				{
				    					discountRuleSet.setxMonthsCoExistPlan(cell.getStringCellValue().replace("\"", ""));
				    				} else if (cell.getColumnIndex()== 15)
				    				{
				    					discountRuleSet.setFixedAmount(cell.getStringCellValue().replace("\"", ""));
				    				} else if (cell.getColumnIndex()== 16)
				    				{
				    					discountRuleSet.setFixedAmountCoExistPlan(cell.getStringCellValue().replace("\"", ""));
				    				} else if (cell.getColumnIndex()== 17)
				    				{
				    					discountRuleSet.setxPercent(cell.getStringCellValue().replace("\"", ""));
				    				} else if (cell.getColumnIndex()== 18)
				    				{
				    					discountRuleSet.setxPercentCoExistPlan(cell.getStringCellValue().replace("\"", ""));
				    				} else if (cell.getColumnIndex()== 19)
				    				{
				    					if (cell.getStringCellValue().replace("\"", "").trim().equals(inCampaign.getCampaignCode()))
				    					{
				    						campaignMatchIndicator = true;
				    					} else {
				    						campaignMatchIndicator = false;				    						
				    					}
				    				}   				    					
				    			}
				    		}
				    	}
				    	if (cell.getColumnIndex() == 20 && logDiscountEntry && campaignMatchIndicator)
				    	{
				    		logDiscountEntry = false;
				    		discountRuleSets.add(discountRuleSet);
				    	}
				    }
				}
			} 
  
            // Closing file output streams 
            file.close(); 
        }   
        // Catch block to handle exceptions 
        catch (Exception e) { 
  
            // Display the exception along with line number 
            // using printStackTrace() method 
            e.printStackTrace(); 
        } 
        
        if (discountRuleSets != null && discountRuleSets.size()>0)
        {
        	campaign.setDiscountRulesets(discountRuleSets);
        }
								
		return campaignRepository.save(campaign);
	}

	@PutMapping("/campaign/{id}")
	public ResponseEntity<Campaign> updateCampaign(@PathVariable(value = "id") int campaignId,
			@RequestBody Campaign inCampaign) throws ResourceNotFoundException {
		Campaign campaign = campaignRepository.findById(campaignId)
				.orElseThrow(() -> new ResourceNotFoundException("Campaign not found for this id :: " + campaignId));

		campaign.setCampaignCode(inCampaign.getCampaignCode());
		campaign.setCampaignName(inCampaign.getCampaignName());
		campaign.setCampaignDesc(inCampaign.getCampaignDesc());
		campaign.setCampaignStartDate(inCampaign.getCampaignStartDate());
		campaign.setCampaignEndDate(inCampaign.getCampaignEndDate());
		campaign.setChannels(inCampaign.getChannels());
		campaign.setPlanCode(inCampaign.getPlanCode());
		campaign.setFlyers(inCampaign.getFlyers());
		campaign.setTag(inCampaign.getTag());
		campaign.setApprovalDate(inCampaign.getApprovalDate());
		campaign.setCampaignDiscountRulesLocation(inCampaign.getCampaignDiscountRulesLocation());
		campaign.setCoExistFlag(inCampaign.isCoExistFlag());
		campaign.setStatus(inCampaign.getStatus());
		campaign.setVersion(inCampaign.getVersion());

		final Campaign updatedCampaign = campaignRepository.save(campaign);
		return ResponseEntity.ok(updatedCampaign);
	}

	@DeleteMapping("/campaign/{id}")
	public Map<String, Boolean> deleteCampaign(@PathVariable(value = "id") int campaignId)
			throws ResourceNotFoundException {
		Campaign campaign = campaignRepository.findById(campaignId)
				.orElseThrow(() -> new ResourceNotFoundException("Campaign not found for this id :: " + campaignId));

		campaignRepository.delete(campaign);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
}
