package com.ctflife.ccs.admin.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;

/**
 * Flyer
 */


public class Flyer   {
  @JsonProperty("URL")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String URL = null;

  /**
   * Gets or Sets lang
   */
  public enum LangEnum {
    EN_US("en-us"),
    
    ZH_HK("zh-hk"),
    
    ZH_CN("zh-cn");

    private String value;

    LangEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static LangEnum fromValue(String text) {
      for (LangEnum b : LangEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("lang")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private LangEnum lang = null;

  @JsonProperty("attachedToPolicy")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Boolean attachedToPolicy = null;


  public Flyer URL(String URL) { 

    this.URL = URL;
    return this;
  }

  /**
   * Get URL
   * @return URL
   **/
  
  @Schema(example = "https://mystorage_location/flyer1_en_us.pdf", description = "")
  
  public String getURL() {  
    return URL;
  }



  public void setURL(String URL) { 
    this.URL = URL;
  }

  public Flyer lang(LangEnum lang) { 

    this.lang = lang;
    return this;
  }

  /**
   * Get lang
   * @return lang
   **/
  
  @Schema(description = "")
  
  public LangEnum getLang() {  
    return lang;
  }



  public void setLang(LangEnum lang) { 
    this.lang = lang;
  }

  public Flyer attachedToPolicy(Boolean attachedToPolicy) { 

    this.attachedToPolicy = attachedToPolicy;
    return this;
  }

  /**
   * The field information will pass to eBao so that eBao would know whether need to attach flyer into policy doc when issuing policy
   * @return attachedToPolicy
   **/
  
  @Schema(description = "The field information will pass to eBao so that eBao would know whether need to attach flyer into policy doc when issuing policy")
  
  public Boolean isAttachedToPolicy() {  
    return attachedToPolicy;
  }



  public void setAttachedToPolicy(Boolean attachedToPolicy) { 
    this.attachedToPolicy = attachedToPolicy;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Flyer flyer = (Flyer) o;
    return Objects.equals(this.URL, flyer.URL) &&
        Objects.equals(this.lang, flyer.lang) &&
        Objects.equals(this.attachedToPolicy, flyer.attachedToPolicy);
  }

  @Override
  public int hashCode() {
    return Objects.hash(URL, lang, attachedToPolicy);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Flyer {\n");
    
    sb.append("    URL: ").append(toIndentedString(URL)).append("\n");
    sb.append("    lang: ").append(toIndentedString(lang)).append("\n");
    sb.append("    attachedToPolicy: ").append(toIndentedString(attachedToPolicy)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
