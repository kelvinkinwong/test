package com.ctflife.ccs.admin.model;

import java.util.List;

public class DiscountRuleSet {
	private int discountId;	
	private String campaignCode;	
	private Long apeFrom;
	private Long apeTo;
	private Boolean apeMeasured;
	private Integer numOfFamMemEligibleFrom;
	private Integer numOfFamMemEligibleTo;
	private List<String> designatedPlanInPolicy;
	private Boolean diffInsuredInDesignatedPolicy;
	private Boolean isExistingCustomer;
	private List<String> coExistPurchasePlan;
	private Long minAP;
	private String payTerm;
	private String xPercent;
	private String xPercentCoExistPlan;
	private String xMonths;
	private String xMonthsCoExistPlan;
	private String fixedAmount;
	private String fixedAmountCoExistPlan;

	public int getDiscountId() {
		return discountId;
	}
	public void setDiscountId(int discountId) {
		this.discountId = discountId;
	}
	public Long getApeFrom() {
		return apeFrom;
	}
	public void setApeFrom(Long apeFrom) {
		this.apeFrom = apeFrom;
	}
	public Long getApeTo() {
		return apeTo;
	}
	public void setApeTo(Long apeTo) {
		this.apeTo = apeTo;
	}
	public Boolean getApeMeasured() {
		return apeMeasured;
	}
	public void setApeMeasured(Boolean apeMeasured) {
		this.apeMeasured = apeMeasured;
	}
	public Integer getNumOfFamMemEligibleFrom() {
		return numOfFamMemEligibleFrom;
	}
	public void setNumOfFamMemEligibleFrom(Integer numOfFamMemEligibleFrom) {
		this.numOfFamMemEligibleFrom = numOfFamMemEligibleFrom;
	}
	public Integer getNumOfFamMemEligibleTo() {
		return numOfFamMemEligibleTo;
	}
	public void setNumOfFamMemEligibleTo(Integer numOfFamMemEligibleTo) {
		this.numOfFamMemEligibleTo = numOfFamMemEligibleTo;
	}
	public List<String> getDesignatedPlanInPolicy() {
		return designatedPlanInPolicy;
	}
	public void setDesignatedPlanInPolicy(List<String> designatedPlanInPolicy) {
		this.designatedPlanInPolicy = designatedPlanInPolicy;
	}
	public Boolean getDiffInsuredInDesignatedPolicy() {
		return diffInsuredInDesignatedPolicy;
	}
	public void setDiffInsuredInDesignatedPolicy(Boolean diffInsuredInDesignatedPolicy) {
		this.diffInsuredInDesignatedPolicy = diffInsuredInDesignatedPolicy;
	}
	public Boolean isExistingCustomer() {
		return isExistingCustomer;
	}
	public void setExistingCustomer(Boolean isExistingCustomer) {
		this.isExistingCustomer = isExistingCustomer;
	}
	public long getMinAP() {
		return minAP;
	}
	public void setMinAP(long minAP) {
		this.minAP = minAP;
	}
	public String getPayTerm() {
		return payTerm;
	}
	public void setPayTerm(String payTerm) {
		this.payTerm = payTerm;
	}
	public String getxPercent() {
		return xPercent;
	}
	public void setxPercent(String xPercent) {
		this.xPercent = xPercent;
	}
	public String getxPercentCoExistPlan() {
		return xPercentCoExistPlan;
	}
	public void setxPercentCoExistPlan(String xPercentCoExistPlan) {
		this.xPercentCoExistPlan = xPercentCoExistPlan;
	}
	public String getxMonths() {
		return xMonths;
	}
	public void setxMonths(String xMonths) {
		this.xMonths = xMonths;
	}
	public String getxMonthsCoExistPlan() {
		return xMonthsCoExistPlan;
	}
	public void setxMonthsCoExistPlan(String xMonthsCoExistPlan) {
		this.xMonthsCoExistPlan = xMonthsCoExistPlan;
	}
	public String getFixedAmount() {
		return fixedAmount;
	}
	public void setFixedAmount(String fixedAmount) {
		this.fixedAmount = fixedAmount;
	}
	public String getFixedAmountCoExistPlan() {
		return fixedAmountCoExistPlan;
	}
	public void setFixedAmountCoExistPlan(String fixedAmountCoExistPlan) {
		this.fixedAmountCoExistPlan = fixedAmountCoExistPlan;
	}
	public List<String> getCoExistPurchasePlan() {
		return coExistPurchasePlan;
	}
	public void setCoExistPurchasePlan(List<String> coExistPurchasePlan) {
		this.coExistPurchasePlan = coExistPurchasePlan;
	}
	public String getCampaignCode() {
		return campaignCode;
	}
	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}		
}
