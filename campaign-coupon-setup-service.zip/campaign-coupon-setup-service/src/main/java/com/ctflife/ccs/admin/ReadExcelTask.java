package com.ctflife.ccs.admin;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;

import org.apache.poi.ss.usermodel.CellType;

import org.apache.poi.ss.usermodel.Row;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ReadExcelTask {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String excelFilePath = "/Users/kelvinwong/Documents/discountRulesetv01.xlsx";
		String value = "";
		boolean logDiscountEntry = false;

		 // Try block to check for exceptions 
        try { 
  
            // Reading file from local directory 
            FileInputStream file = new FileInputStream(excelFilePath); 
  
            try (// Create Workbook instance holding reference to 
			            // .xlsx file 
            	XSSFWorkbook workbook = new XSSFWorkbook(file)) {
				// Get first/desired sheet from the workbook 
				XSSFSheet sheet = workbook.getSheetAt(0); 
  
				// Iterate through each rows one by one 
				Iterator<Row> rowIterator = sheet.iterator(); 
  
				// Till there is an element condition holds true 
				while (rowIterator.hasNext()) {   
				    Row row = rowIterator.next(); 
  
				    for (Cell cell: row)
				    {
				    	if (cell.getCellType() == CellType.NUMERIC)
				    	{
				    		if (logDiscountEntry)
				    		{
				    			System.out.print("idx:" + cell.getColumnIndex() + "@" +  
				    					cell.getNumericCellValue() 
				                    	+ "|");
				    		}
				    	} else if (cell.getCellType() == CellType.STRING)
				    	{
				    		if (cell.getColumnIndex() == 0 && cell.getStringCellValue().length()>5 && cell.getStringCellValue().substring(0, 5).equals("Rule-"))
				    		{
				    			logDiscountEntry = true;				    			
				    		}
				    		
				    		if (logDiscountEntry)
				    		{
				    			System.out.print("idx:" + cell.getColumnIndex() + "@" + 
				    					cell.getStringCellValue() 
				                    	+ "|");
				    		}
				    	} else if (cell.getCellType() == CellType.BOOLEAN)
				    	{
				    		if (logDiscountEntry)
				    		{
				    			System.out.print("idx:" + cell.getColumnIndex() + "@" +  
				    					cell.getBooleanCellValue()
				                    	+ "|");
				    		}
				    	}
				    	if (cell.getColumnIndex() == 20 && logDiscountEntry)
				    	{
				    		logDiscountEntry = false;
						    System.out.println(""); 
				    	}
				    }
				      
				}
			} 
  
            // Closing file output streams 
            file.close(); 
        } 
  
        // Catch block to handle exceptions 
        catch (Exception e) { 
  
            // Display the exception along with line number 
            // using printStackTrace() method 
            e.printStackTrace(); 
        } 
		
	}
}
