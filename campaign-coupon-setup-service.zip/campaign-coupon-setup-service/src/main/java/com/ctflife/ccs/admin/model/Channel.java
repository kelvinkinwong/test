package com.ctflife.ccs.admin.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;

//import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import javax.validation.Valid;


/**
 * Channel
 */


public class Channel   {
  /**
   * Eligible Channels
   */
  public enum ChannelEnum {
    TIEDAGENCY("TiedAgency"),
    
    BROKERAGE("Brokerage"),
    
    IFAANDBROKERAGE("IFAandBrokerage"),
    
    IFAANDBROKERAGELIFE("IFAandBrokerageLife"),
    
    PARTNERSHIPSERVICES("PartnershipServices"),
    
    PREMIERBUSINESS("PremierBusiness"),
    
    CORPORATEAGENCY("CorporateAgency"),
    
    ALL("All");

    private String value;

    ChannelEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ChannelEnum fromValue(String text) {
      for (ChannelEnum b : ChannelEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("channel")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private ChannelEnum channel = null;

  @JsonProperty("hasCommissionScarificeOption")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Boolean hasCommissionScarificeOption = null;

  @JsonProperty("commissionSacrifice")
  @Valid
  private List<CommissionSacrifice> commissionSacrifice = null;

  public Channel channel(ChannelEnum channel) { 

    this.channel = channel;
    return this;
  }

  /**
   * Eligible Channels
   * @return channel
   **/
  
  @Schema(example = "IFAandBrokerageLife", description = "Eligible Channels")
  
  public ChannelEnum getChannel() {  
    return channel;
  }



  public void setChannel(ChannelEnum channel) { 
    this.channel = channel;
  }

  public Channel hasCommissionScarificeOption(Boolean hasCommissionScarificeOption) { 

    this.hasCommissionScarificeOption = hasCommissionScarificeOption;
    return this;
  }

  /**
   * Get hasCommissionScarificeOption
   * @return hasCommissionScarificeOption
   **/
  
  @Schema(description = "")
  
  public Boolean isHasCommissionScarificeOption() {  
    return hasCommissionScarificeOption;
  }

  public void setHasCommissionScarificeOption(Boolean hasCommissionScarificeOption) { 
    this.hasCommissionScarificeOption = hasCommissionScarificeOption;
  }

  public Channel commissionSacrifice(List<CommissionSacrifice> commissionSacrifice) { 

    this.commissionSacrifice = commissionSacrifice;
    return this;
  }

  public Channel addCommissionSacrificeItem(CommissionSacrifice commissionSacrificeItem) {
    if (this.commissionSacrifice == null) {
      this.commissionSacrifice = new ArrayList<CommissionSacrifice>();
    }
    this.commissionSacrifice.add(commissionSacrificeItem);
    return this;
  }

  /**
   * Get commissionSacrifice
   * @return commissionSacrifice
   **/
  
  @Schema(description = "")
  @Valid
  public List<CommissionSacrifice> getCommissionSacrifice() {  
    return commissionSacrifice;
  }



  public void setCommissionSacrifice(List<CommissionSacrifice> commissionSacrifice) { 
    this.commissionSacrifice = commissionSacrifice;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Channel channel = (Channel) o;
    return Objects.equals(this.channel, channel.channel) &&
        Objects.equals(this.hasCommissionScarificeOption, channel.hasCommissionScarificeOption) &&
        Objects.equals(this.commissionSacrifice, channel.commissionSacrifice);
  }

  @Override
  public int hashCode() {
    return Objects.hash(channel, hasCommissionScarificeOption, commissionSacrifice);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Channel {\n");
    
    sb.append("    channel: ").append(toIndentedString(channel)).append("\n");
    sb.append("    hasCommissionScarificeOption: ").append(toIndentedString(hasCommissionScarificeOption)).append("\n");
    sb.append("    commissionSacrifice: ").append(toIndentedString(commissionSacrifice)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
